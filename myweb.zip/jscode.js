var i = 0;
var txt = '....Hi my name is Amit Purohit. and I am a UI Developer' ;
var speed = 50;

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("demo1").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}
typeWriter();